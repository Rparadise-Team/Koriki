PRODUCT
=======
Title:   Safari (VTech, Time & Fun) for gw-libretro
Build:   2017-11-25T14:18:28Z
Author:  Andre Leiradella
E-mail:  andre@leiradella.com
Website: http://bot.libretro.com/assets/cores/gw/

BASED ON
========
Title:   Safari (VTech, Time & Fun) Simulator
Version: S4/1.02
Author:  Luca "MADrigal" Antignano
E-mail:  lucantignano@gmail.com
Website: http://www.madrigaldesign.it/sim/

INSTRUCTIONS
============
Copy the Safari (VTech, Time & Fun).mgw
file into your frontend's content directory and use the frontend to load and
play the game.

RetroArch is feature-complete frontend, and is available for download at
http://www.libretro.com/ for free.

You'll also need the gw-libretro core (available at
https://github.com/libretro/gw-libretro) to be able to load and play mgw
files. gw-libretro is also free.

LICENSE
=======
This work is licensed under the Creative Commons Attribution-NonCommercial-
ShareAlike 4.0 International License. To view a copy of this license, visit
http://creativecommons.org/licenses/by-nc-sa/4.0/.
