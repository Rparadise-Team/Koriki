---
author: Richard McCormack
github: DenialAdams
date: 2022-01-23 00:00:28 GMT
---

# Spunky

A submission to the WASM-4 game jam.

Original page on [itch.io](https://brickcodes.itch.io/spunky).
