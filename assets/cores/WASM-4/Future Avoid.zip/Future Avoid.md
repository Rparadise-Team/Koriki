---
author: Joakim Hentula
github: jockus
date: 2022-01-23 00:00:38 GMT
---

# Future Avoid

A submission to the WASM-4 game jam.

Original page on [itch.io](https://jvvh.itch.io/future-avoid).
