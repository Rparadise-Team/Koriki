---
author: Sander in 't Veld
github: SLiV9
date: 2022-01-23 00:00:43 GMT
---

# You Will Return

A submission to the WASM-4 game jam.

Original page on [itch.io](https://sliv.itch.io/you-will-return).
