---
author: Matúš Chovan
github: grouter
date: 2022-01-23 00:00:37 GMT
---

# Mind Palace

A submission to the WASM-4 game jam.

Original page on [itch.io](https://grouter.itch.io/mind-palace).
