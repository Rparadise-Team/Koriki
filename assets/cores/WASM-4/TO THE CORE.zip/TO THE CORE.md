---
author: Garrett Hale
github: Gertkeno
date: 2022-01-23 00:00:35 GMT
---

# TO THE CORE

Play as pant ant in TO THE CORE a semi-idle game journeying to the center of the
earth, and his home. Fear not for Wormie will guide you on your quest through my
esoteric rules, so put your reading noggin on!

Written in Zig 0.9, [source available on github.com](https://github.com/Gertkeno/to-the-core)

- *Update 2022-01-30: added tool info*

## CONTROLS

- Z to open your tool kit

- X to select the tool and use it!
- Z get tool info!
