---
author: André L. Alvares
github: Andre-LA
date: 2022-01-23 00:00:22 GMT
---

# Micro Quest

A submission to the WASM-4 game jam.

Original page on [itch.io](https://andre-la.itch.io/micro-quest).
