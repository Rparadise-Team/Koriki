---
author: Mateusz Czarnecki
github: blackstaff
date: 2022-01-23 00:00:12 GMT
---

# Don't Smash Into Obstacles

A submission to the WASM-4 game jam.

Original page on [itch.io](https://blackstaff92.itch.io/dont-smash-into-obstacles).
