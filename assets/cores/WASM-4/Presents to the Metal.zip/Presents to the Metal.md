---
author: errorStream
github: mallow-malt
date: 2022-01-23 00:00:23 GMT
---

# Presents to the Metal

A submission to the WASM-4 game jam.

Original page on [itch.io](https://errorstream.itch.io/presents-to-the-metal).
