---
author: Jonathan Derque
github: jonathanderque
date: 2022-02-01
---

# Lingword