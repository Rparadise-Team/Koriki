---
author: Ben Smith
github: binji
date: 2021-12-19
---

# Maze