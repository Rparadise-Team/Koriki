---
author: Philipp Lühmann
github: luehmann
date: 2022-01-23 00:00:27 GMT
---

# Assemblio

A submission to the WASM-4 game jam.

Original page on [itch.io](https://quic5.itch.io/assemblio).
