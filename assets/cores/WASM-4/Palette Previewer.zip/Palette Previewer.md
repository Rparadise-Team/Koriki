---
author: David Sims
github: thedavesims
date: 2021-10-19
---

# Palette Previewer