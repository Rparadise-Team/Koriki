---
author: Venkatesh.H
github: venkatesh-coder
date: 2022-01-23 00:00:09 GMT
---

# Simple Rocket

A submission to the WASM-4 game jam.

Original page on [itch.io](https://venkateshht.itch.io/simple-rocket).
