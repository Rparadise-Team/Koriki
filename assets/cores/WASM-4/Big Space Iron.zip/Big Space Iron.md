---
author: kzerot
github: ghost
date: 2022-01-23 00:00:18 GMT
---

# Big Space Iron

A submission to the WASM-4 game jam.

Original page on [itch.io](https://kzerot.itch.io/big-space-iron).
