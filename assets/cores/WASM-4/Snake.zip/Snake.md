---
author: Tomas Tulka
github: ttulka
date: 2021-11-23
---

# Snake