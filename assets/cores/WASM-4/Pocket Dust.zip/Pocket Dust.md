---
author: Colby Hubscher
github: colbyhub
date: 2022-01-23 00:00:29 GMT
---

# Pocket Dust

A submission to the WASM-4 game jam.

Original page on [itch.io](https://colbyhub.itch.io/pocket-dust).
