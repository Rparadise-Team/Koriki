---
author: Troy Wiegand
github: troywiegand
date: 2022-01-23 00:00:11 GMT
---

# Wumpus Hunt

A submission to the WASM-4 game jam.

Original page on [itch.io](https://troywiegand.itch.io/wumpus-hunt).
