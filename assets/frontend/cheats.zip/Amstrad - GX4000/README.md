# Gents: Amstrad - GX4000 Cheats for RetroArch

All Cheats created by Gent of [Emucheats](https://emucheats.emulation64.com/)
You can also get in touch via Discord and the [Emucheats Discord Channel](https://discord.gg/aEEtyj6)

All Cheats were created using RetroArch Caprice32 Core. Any support missing is due to issues with the emulator and will be catered for once they are working.