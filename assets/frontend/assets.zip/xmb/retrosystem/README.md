Retrosystem Theme for RetroArch & Lakka
====================

About Retrosystem
-----------------

 Based on Retroactive marked from [baxysqyare](https://github.com/baxysquare/baxy-retroarch-themes) 
 Mixed with Systematic (same repo)
 Color changes to improve contrast
 Added more detail
 Completely changed some icons
 Other misc changes

	
### Theme Font
 
 [DejaVu Sans](https://dejavu-fonts.github.io/) under a free [License](https://dejavu-fonts.github.io/License.html)
 