All source image patterns downloaded from www.subtlepatterns.com
